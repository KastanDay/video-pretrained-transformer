Command-line interface
======================

.. click:: lhotse.bin:cli
   :prog: lhotse
   :show-nested:
